﻿using Microsoft.EntityFrameworkCore;
using SnacksServeApi.Models;

namespace SnacksServeApi.Repositories
{
    public class SnacksServeDbContext : DbContext
    {
        public SnacksServeDbContext(DbContextOptions options) : base(options) { }
        public DbSet<Person> Person { get; set; }
        public DbSet<SnacksServeTask> ServeTask { get; set; }
        public DbSet<Log> Log { get;set; }
    }
}

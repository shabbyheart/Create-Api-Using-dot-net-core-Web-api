﻿using Microsoft.EntityFrameworkCore;

namespace SnacksServeApi.Repositories
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly SnacksServeDbContext context;
        private DbSet<T> DbSet;

        IEnumerable<T> IRepository<T>.GetAlls => throw new System.NotImplementedException();

        public Repository(SnacksServeDbContext _context)
        {
            this.context = _context;
            DbSet = context.Set<T>();
        }
        public IEnumerable<T> GetAll()
        {
            return DbSet.AsEnumerable();
        }
        public void Add(T entity)
        {
            DbSet.Add(entity);
            context.SaveChanges();
        }
        public void Update(T entity)
        {
            DbSet.Attach(entity);
            context.Entry(entity).State = EntityState.Modified;
            context.SaveChanges();
        }
        public void Delete(T entity)
        {
            DbSet.Remove(entity);
            context.SaveChanges();
        }
        public T? FindById(string id)
        {
            return DbSet.Find(id);
        }
        
        public void DeleteAllRow(IEnumerable<T> rows)
        {
            foreach(T row in rows)
            {
                DbSet.Remove(row);
            }
            context.SaveChanges();
        }
    }
}

﻿using System.Collections.Generic;
namespace SnacksServeApi.Repositories
{
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> GetAlls{get;}
        IEnumerable<T> GetAll();
        void Add(T entity);
        void Delete(T entity);
        void Update(T entity);
        T? FindById(string Id);
        void DeleteAllRow(IEnumerable<T> rows);
    }
}

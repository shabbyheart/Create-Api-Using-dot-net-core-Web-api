﻿using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Models;
using SnacksServeApi.Repositories;
using SnacksServeApi.Services.Person_SnacksServeTask_Shared_Services;


namespace SnacksServeApi.Services.SnacksServeTaskServices
{
    public class SnacksServeTaskService : ISnacksServeTaskService
    {
        private readonly IRepository<SnacksServeTask> _repository;
        private readonly IPersonTaskSharedServices _personTaskSharedService;
        
        public SnacksServeTaskService(IRepository<SnacksServeTask> repository, IPersonTaskSharedServices personTaskSharedService)
        {
            _repository = repository;
            _personTaskSharedService = personTaskSharedService;
        }
        public List<SnacksServeTaskDto> GetAllTaskDetails()
        {
            List<SnacksServeTaskDto> tasks = _personTaskSharedService.GetAllTaskDetails();
            return tasks;
        }

        public SnacksServeTaskDto GetById(string id)
        {
            // check id is exists is or not.
            var ExistsTask = _repository.FindById(id.Trim());
            _ = ExistsTask ?? throw new Exception($"Task with Id {id} doesn't exist");

            return new SnacksServeTaskDto()
            {
                Id = ExistsTask.Id,
                Name = ExistsTask.Name,
                PersonId = ExistsTask.PersonId,
                IsComplete = ExistsTask.IsComplete,
                WhoCompleted = ExistsTask.WhoCompleted,
            };
        }

        public List<SnacksServeTaskDto> GetByTaskName(string taskName)
        {
            taskName = taskName.Trim();
            List<SnacksServeTaskDto> tasks = new List<SnacksServeTaskDto>();

            var ExistsTasks = _repository.GetAll();
            if (!ExistsTasks.Any()) throw new Exception($"Task Table is Empty");
            var data = ExistsTasks.Where(x => x.Name.ToLower().Contains(taskName.ToLower())).ToList();
            if(!data.Any()) throw new Exception($" {taskName} doesn't exist");
            foreach (var taskItem in data)
            {
                tasks.Add(new SnacksServeTaskDto()
                {
                    Name = taskItem.Name,
                    Id = taskItem.Id,
                    PersonId = taskItem.PersonId,
                    IsComplete = taskItem.IsComplete,
                    WhoCompleted = taskItem.WhoCompleted,
                });
            }
            return tasks;
        }

        public string CreateAllTask()
        {
            List<PersonDto> personsDetailsList = _personTaskSharedService.GetAllPersonDetails();
            
            IEnumerable<SnacksServeTask> tasks = _repository.GetAll();
            if (tasks.Any())
            {
                _repository.DeleteAllRow(tasks);
            }
            
            foreach (PersonDto person in personsDetailsList)
            {
                
                SnacksServeTask task = new SnacksServeTask()
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = "bring " + person.SnacksName,
                    PersonId = person.Id,
                    IsComplete = false,
                };
                _repository.Add(task);
            }
            return "All Tasks Created";
        }

        public SnacksServeTaskDto CreateTask(CreateSnacksServeTaskDto createTaskDto)
        {
            // for checking person id is exit or not.
            var ExistsPersons = _personTaskSharedService.GetAllPersonDetails();
            var ExistingPerson = ExistsPersons.SingleOrDefault(person => person.Id == createTaskDto.PersonId.Trim());
            _ = ExistingPerson ?? throw new Exception($"Person with Id {createTaskDto.PersonId} doesn't exists");

            // check already a task is created or not for this person 
            var ExistsTasks = _personTaskSharedService.GetAllTaskDetails(); 
            if (ExistsTasks.Any())
            {
                var ExistingTask = ExistsTasks.SingleOrDefault(task => task.PersonId == ExistingPerson.Id);
                if (ExistingTask != null)
                {
                    throw new Exception($"Already a task is created for {ExistingPerson.Name}");
                }
            }
            SnacksServeTask task = new SnacksServeTask()
            {
                Id = Guid.NewGuid().ToString(),
                Name = "bring " + createTaskDto.SnacksName,
                PersonId = ExistingPerson.Id,
                IsComplete = false,
                WhoCompleted = null,
            };
            _repository.Add(task);

            return new SnacksServeTaskDto()
            {
                Id = task.Id,
                Name = task.Name,
                PersonId = task.PersonId,
                IsComplete = task.IsComplete,
                WhoCompleted = task.WhoCompleted,
            };
        }

        public SnacksServeTaskDto UpdateTask(UpdateSnacksServeTaskDto task)
        {
            var ExistsTask = _repository.FindById(task.Id.Trim());
            _ = ExistsTask ?? throw new Exception($"Task with Id {task.Id} doesn't exist");

            ExistsTask.Name = "bring " + task.SnacksName;
            ExistsTask.Id = task.Id;

            _repository.Update(ExistsTask);
            return new SnacksServeTaskDto() { 
                Id = ExistsTask.Id, 
                Name = ExistsTask.Name,
                PersonId = ExistsTask.PersonId,
                IsComplete = ExistsTask.IsComplete,
                WhoCompleted = ExistsTask.WhoCompleted,
            };
        }

        public string DeleteTask(string taskId)
        {
            var existingTask = _repository.FindById(taskId.Trim());
            _ = existingTask ?? throw new Exception($"Task with ID {taskId} doesn't exist");

            _repository.Delete(existingTask);
            return "Delete Successful";
        }
    }
}

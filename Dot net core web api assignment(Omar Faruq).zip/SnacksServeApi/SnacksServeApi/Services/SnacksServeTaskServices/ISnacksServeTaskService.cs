﻿using SnacksServeApi.DTO.SnacksServeTaskDTOs;

namespace SnacksServeApi.Services.SnacksServeTaskServices
{
    public interface ISnacksServeTaskService
    {
        List<SnacksServeTaskDto> GetAllTaskDetails();
        SnacksServeTaskDto GetById(string id);
        List<SnacksServeTaskDto> GetByTaskName(string taskName);
        SnacksServeTaskDto CreateTask(CreateSnacksServeTaskDto createTaskDto);
        string CreateAllTask();
        SnacksServeTaskDto UpdateTask(UpdateSnacksServeTaskDto task);
        string DeleteTask(string taskId);
    }
}

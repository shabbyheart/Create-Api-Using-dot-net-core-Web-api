﻿using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Models;
using SnacksServeApi.Repositories;
using System.Threading.Tasks;

namespace SnacksServeApi.Services.Person_SnacksServeTask_Shared_Services
{
    public class PersonTaskSharedServices : IPersonTaskSharedServices
    {
        private readonly IRepository<SnacksServeTask> _repositoryTask;
        private readonly IRepository<Person> _repositoryPerson;
        public PersonTaskSharedServices(IRepository<SnacksServeTask> repositoryTask, IRepository<Person> repositoryPerson)
        {
            _repositoryTask = repositoryTask;
            _repositoryPerson = repositoryPerson;
        }

        public CompleteSnacksServeTaskDto CompleteTheTask(CompleteSnacksServeTaskDto completeTaskDto)
        {
            var ExistingTask = _repositoryTask.FindById(completeTaskDto.Id.Trim());
            _ = ExistingTask ?? throw new Exception($"Task with Id {completeTaskDto.Id} doesn't exist");

            ExistingTask.Name = completeTaskDto.Name;
            ExistingTask.Id = completeTaskDto.Id;
            ExistingTask.IsComplete = completeTaskDto.IsComplete;
            ExistingTask.WhoCompleted = completeTaskDto.WhoCompleted;

            _repositoryTask.Update(ExistingTask);

            return new CompleteSnacksServeTaskDto()
            {
                Id = ExistingTask.Id,
                Name = ExistingTask.Name,
                IsComplete = ExistingTask.IsComplete,
                WhoCompleted = ExistingTask.WhoCompleted,
            };
        }

        public List<PersonDto> GetAllPersonDetails()
        {
            var allPerson = new List<PersonDto>();
            IEnumerable<Person> ExistsPersons = _repositoryPerson.GetAll();
            if (!ExistsPersons.Any()) throw new Exception($" Person Table is empty");
            foreach (Person person in ExistsPersons)
            {
                allPerson.Add(new PersonDto()
                {
                    Id = person.Id,
                    Name = person.Name,
                    SnacksName = person.SnacksName,
                });
            }
            return allPerson;
        }
        public List<SnacksServeTaskDto> GetAllTaskDetails()
        {
            List<SnacksServeTaskDto> tasks = new List<SnacksServeTaskDto>();
            var ExistsTasks = _repositoryTask.GetAll();
            if (!ExistsTasks.Any()) throw new Exception($"Task Table is Empty");
            foreach (var item in ExistsTasks)
            {
                var taskDto = new SnacksServeTaskDto();

                taskDto.Id = item.Id;
                taskDto.Name = item.Name;
                taskDto.PersonId = item.PersonId;
                taskDto.IsComplete = item.IsComplete;
                taskDto.WhoCompleted = item.WhoCompleted;
                tasks.Add(taskDto);
            }
            return tasks;
        }
    }
}

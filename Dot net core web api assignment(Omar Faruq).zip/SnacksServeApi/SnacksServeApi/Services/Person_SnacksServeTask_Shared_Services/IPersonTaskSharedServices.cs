﻿using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;

namespace SnacksServeApi.Services.Person_SnacksServeTask_Shared_Services
{
    public interface IPersonTaskSharedServices
    {
        List<PersonDto> GetAllPersonDetails();
        List<SnacksServeTaskDto> GetAllTaskDetails();
        CompleteSnacksServeTaskDto CompleteTheTask(CompleteSnacksServeTaskDto completeTaskDto);
        //string UpdateTask(UpdateSnacksServeTaskDto task);
    }
}

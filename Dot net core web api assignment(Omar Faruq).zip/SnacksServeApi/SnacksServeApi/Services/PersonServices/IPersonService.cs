﻿using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Models;

namespace SnacksServeApi.Services.PersonServices
{
    public interface IPersonService
    {
        List<PersonDto> GetAllPersonDetails();
        PersonDto GetById(string id);
        RequestedSnacksServeTaskDto GetRequestedTaskByPersonName(string personName);
        List<ToDoSnacksServeTaskDto> GetToDoTasksByPersonName(string personName);
        CompleteSnacksServeTaskDto CompleteTheTask(string personId, string snacksServeTaskId);
        List<ShowCompletedSnacksServeTaskDto> GetCompletedTasksByPersonName(string personName);
        PersonDto PersonCreate(CreatePersonDto person);
        UpdatePerssonDto UpdatePerson(UpdatePerssonDto person);
        string DeleteById(string id);
    }
}

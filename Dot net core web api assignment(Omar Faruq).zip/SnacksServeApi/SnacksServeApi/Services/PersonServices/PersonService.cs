﻿using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Models;
using SnacksServeApi.Repositories;
using SnacksServeApi.Services.Person_SnacksServeTask_Shared_Services;
using SnacksServeApi.Services.SnacksServeTaskServices;
namespace SnacksServeApi.Services.PersonServices
{
    public class PersonService : IPersonService
    {
        private readonly IRepository<Person> _repository;
        //private readonly ISnacksServeTaskService _snacksServeTaskService;
        //private readonly ISnacksServeTaskService _snacksServeTaskService;
        private readonly IPersonTaskSharedServices _personTaskSharedService;
        public PersonService(IRepository<Person> repository, IPersonTaskSharedServices personTaskSharedService)// , ISnacksServeTaskService snacksServeTaskService)
        {
            _repository = repository;
            _personTaskSharedService = personTaskSharedService;
            //_snacksServeTaskService = snacksServeTaskService;
        }
        public List<PersonDto> GetAllPersonDetails()
        {
            var allPerson = _personTaskSharedService.GetAllPersonDetails();
            return allPerson;
        }
        public PersonDto GetById(string id)
        {
            var existingPerson = _repository.FindById(id.Trim());
            _ = existingPerson ?? throw new Exception($"Person with Id {id} doesn't exist");

            return new PersonDto() { Id = existingPerson.Id, Name = existingPerson.Name, SnacksName = existingPerson.SnacksName };
        }

        public RequestedSnacksServeTaskDto GetRequestedTaskByPersonName(string personName)
        {
            personName = personName.Trim();
            // First get person id
            IEnumerable<Person> ExistsPersons = _repository.GetAll();
            if (!ExistsPersons.Any()) throw new Exception($" Person Table is empty");
            var ExistingPerson = ExistsPersons.FirstOrDefault(person => person.Name.ToLower() == personName.ToLower());
            _ = ExistingPerson ?? throw new Exception($" {personName} doesn't exist");
            string personId = ExistingPerson.Id; /// person id gotted

            /// check whether a task is assigned for this person
            var ExistsTasks = _personTaskSharedService.GetAllTaskDetails();
            var ExistingTask = ExistsTasks.SingleOrDefault(task => task.PersonId == personId);
            _ = ExistingTask ?? throw new Exception($"There is no Task requested by {personName}");

            return new RequestedSnacksServeTaskDto() { Id = ExistingTask.Id, Name = ExistingTask.Name };
        }

        public List<ToDoSnacksServeTaskDto> GetToDoTasksByPersonName(string personName)
        {
            personName = personName.Trim();
            List<ToDoSnacksServeTaskDto> ToDoTaskList = new List<ToDoSnacksServeTaskDto>();

            // First get person id
            IEnumerable<Person> ExistsPersons = _repository.GetAll();
            if (!ExistsPersons.Any()) throw new Exception($" Person Table is empty");
            var ExistingPerson = ExistsPersons.FirstOrDefault(person => person.Name.ToLower() == personName.ToLower());
            _ = ExistingPerson ?? throw new Exception($" {personName} doesn't exist");
            string personId = ExistingPerson.Id;

            
            var ExistsTasks = _personTaskSharedService.GetAllTaskDetails();
            var ExistingTask = ExistsTasks.SingleOrDefault(task => task.PersonId == personId);
            _ = ExistingTask ?? throw new Exception($"There is no Task requested by {personName}");
            foreach (var task in ExistsTasks)
            {
                if (task.IsComplete == false)
                {
                    ToDoTaskList.Add(new ToDoSnacksServeTaskDto(){Id = task.Id, Name = task.Name});
                }
            }
            return ToDoTaskList;
        }

        public CompleteSnacksServeTaskDto CompleteTheTask(string personId, string snacksServeTaskId)
        {
            personId = personId.Trim();
            snacksServeTaskId = snacksServeTaskId.Trim();

            // first check personId exists or not
            var ExistingPerson =  _repository.FindById(personId);
            _ = ExistingPerson ?? throw new Exception($"Person with {personId} doesn't exist");
            string ExistingPersonName = ExistingPerson.Name;
            string ExistingPersonId = ExistingPerson.Id;

            // Get ALL Data from SnacksServeTask then get target task and update it.
            var ExistsTasks = _personTaskSharedService.GetAllTaskDetails();
            var ExistingTask = ExistsTasks.SingleOrDefault( task => task.Id == snacksServeTaskId);
            _ = ExistingTask ?? throw new Exception($"Task with {snacksServeTaskId} doesn't exists");

            var data = ExistsTasks.SingleOrDefault(task => task.PersonId == ExistingPersonId);
            _ = data ?? throw new Exception($"There is no Task requested by {ExistingPersonName}");
            if (ExistingTask.IsComplete == true)
            {
                throw new Exception($"This Task Already completed");
            }
            CompleteSnacksServeTaskDto completeTaskDto = new CompleteSnacksServeTaskDto()
            {
                Id = ExistingTask.Id,
                Name = ExistingTask.Name,
                IsComplete = true,
                WhoCompleted = ExistingPersonName,
            };
            return _personTaskSharedService.CompleteTheTask(completeTaskDto);
        }

        public List<ShowCompletedSnacksServeTaskDto> GetCompletedTasksByPersonName(string personName)
        {
            personName = personName.Trim();
            List<ShowCompletedSnacksServeTaskDto> completedTaskList = new List<ShowCompletedSnacksServeTaskDto>();
            
            // get all task from person table
            IEnumerable<Person> ExitPersons = _repository.GetAll();
            if (ExitPersons.Count() == 0) throw new Exception($" Person Table is empty");
            // check this person is exists or not.
            var ExitPerson = ExitPersons.FirstOrDefault(person => person.Name.ToLower() == personName.ToLower());
            _ = ExitPerson ?? throw new Exception($" {personName} doesn't exist");
            string PersonName = ExitPerson.Name;
            string PersonId = ExitPerson.Id;

            /// check whether a task is assigned for this person
            var ExistsTasks = _personTaskSharedService.GetAllTaskDetails();
            var ExistingTask = ExistsTasks.SingleOrDefault(task => task.PersonId == PersonId);
            _ = ExistingTask ?? throw new Exception($"There is no Task requested by {PersonName}");
            foreach (var task in ExistsTasks)
            {
                if (task.WhoCompleted == PersonName)
                {
                    completedTaskList.Add(new ShowCompletedSnacksServeTaskDto()
                    {
                        Id=task.Id,
                        Name=task.Name,
                        PersonId=task.PersonId,
                        WhoCompleted=task.WhoCompleted,
                    });
                }
                    
            }
            return completedTaskList;
        }

        public PersonDto PersonCreate(CreatePersonDto person)
        {
            Person newPerson = new Person()
            {
                Id = Guid.NewGuid().ToString(),
                Name = person.Name,
                SnacksName = person.SnacksName,
            };
            _repository.Add(newPerson);

            return new PersonDto() { Id = newPerson.Id, Name = newPerson.Name, SnacksName = newPerson.SnacksName };

        }
        
        public UpdatePerssonDto UpdatePerson(UpdatePerssonDto personRequest)
        {
            var existingPerson = _repository.FindById(personRequest.Id.Trim());
            _ = existingPerson ?? throw new Exception($"Person with {personRequest.Id} doesn't exist");

            //existingPerson.Id = personRequest.Id;
            existingPerson.SnacksName = personRequest.SnacksName;
            existingPerson.Name = personRequest.Name;

            _repository.Update(existingPerson);
            return new UpdatePerssonDto()
            {
                Id = existingPerson.Id,
                Name = existingPerson.Name,
                SnacksName = existingPerson.SnacksName,
            };
        }
        public string DeleteById(string id)
        {
            var existingPerson = _repository.FindById(id.Trim());
            _ = existingPerson ?? throw new Exception($"Person with {id} doesn't exist");
            _repository.Delete(existingPerson);
            return "Delete Successful";
        } 
    }
}

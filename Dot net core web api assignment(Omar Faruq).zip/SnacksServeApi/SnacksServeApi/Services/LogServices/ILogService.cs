﻿using SnacksServeApi.DTO.LogDtos;

namespace SnacksServeApi.Services.LogServices
{
    public interface ILogService
    {
        void PostLog(CreateLogDto logDto);
        List<LogDto> GetLog();
        void UpdateLastRow(string exception);
    }
}

﻿using SnacksServeApi.DTO.LogDtos;
using SnacksServeApi.Models;
using SnacksServeApi.Repositories;

namespace SnacksServeApi.Services.LogServices
{
    public class LogService : ILogService
    {
        private readonly IRepository<Log> _repository;
        public LogService(IRepository<Log> repository)
        {
            _repository = repository;
        }

        public List<LogDto> GetLog()
        {
            List<LogDto> logDtoList = new List<LogDto>();
            IEnumerable<Log> logList = _repository.GetAll();
            if(logList.Count() == 0)
                throw new Exception($"Table is empty");
            foreach (Log log in logList)
            {
                logDtoList.Add(new LogDto()
                {
                    RequestPath = log.RequestPath,
                    RequestMethod = log.RequestMethod,
                    RequestProtocol = log.RequestProtocol,
                    RequestScheme = log.RequestScheme,
                    RequestHost = log.RequestHost,
                    Exception = log.Exception,
                    DateTime = log.DateTime,
                });
            }
            return logDtoList;
        }

        public void PostLog(CreateLogDto createLogDto)
        {
            if(createLogDto != null)
            {
                Log log = new Log()
                {
                    RequestPath = createLogDto.RequestPath,
                    RequestMethod = createLogDto.RequestMethod,
                    RequestProtocol = createLogDto.RequestProtocol,
                    RequestScheme = createLogDto.RequestScheme,
                    RequestHost = createLogDto.RequestHost,
                    //Exception = logDto.Exception,
                    DateTime = createLogDto.DateTime,
                };
                _repository.Add(log);
            }
        }
        public void UpdateLastRow(string exception)
        {
            //LogDto logDto = new LogDto();
            var ExistsRow = _repository.GetAll().LastOrDefault();
            _ = ExistsRow ?? throw new Exception($"Log Table is Empty");

            ExistsRow.Exception = exception;
            _repository.Update(ExistsRow);  
        }
    }
}

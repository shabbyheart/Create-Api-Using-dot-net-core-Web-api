﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace SnacksServeApi.Models
{
    [Table("log")]
    public class Log
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string RequestPath { get; set; } = string.Empty;
        public string RequestMethod { get; set; } = string.Empty;
        public string RequestProtocol { get; set; } = string.Empty;
        public string RequestScheme { get; set; } = string.Empty;
        public string RequestHost { get; set; } = string.Empty;
        public string? Exception { get; set; } = string.Empty;
        public string DateTime { get; set; } = string.Empty;


    }
}

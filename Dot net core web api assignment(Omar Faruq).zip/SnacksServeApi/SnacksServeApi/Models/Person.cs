﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SnacksServeApi.Models
{
    [Table("person")]
    public class Person
    {
        [Key]
        public string Id { get; set; } = string.Empty;
        [Required]
        public string Name { get; set; } = string.Empty;
        public string SnacksName { get; set; } = string.Empty;

        //public int ServeTaskId { get; set; }
        public SnacksServeTask? ServeTask { get; set; }

    }
}

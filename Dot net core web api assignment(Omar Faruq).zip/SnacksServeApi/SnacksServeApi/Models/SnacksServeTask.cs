﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SnacksServeApi.Models
{
    [Table("snacksServeTask")]
    public class SnacksServeTask
    {
        [Key]
        public string Id{ get; set; } = string.Empty;
        [Required]
        public string Name { get; set; } = string.Empty;

        public string PersonId { get; set; } = string.Empty;
        public Person? Person { get; set; }


        public bool IsComplete { get; set; }
        public string? WhoCompleted { get; set; }

    }
}

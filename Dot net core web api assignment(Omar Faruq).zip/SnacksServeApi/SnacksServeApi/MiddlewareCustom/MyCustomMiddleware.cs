﻿using SnacksServeApi.DTO.LogDtos;
using SnacksServeApi.Models;
using SnacksServeApi.Services.LogServices;


namespace SnacksServeApi.MiddlewareCustom
{
    public class MyCustomMiddleware
    {
        private readonly RequestDelegate _next;

        public MyCustomMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        // ILogService is injected into InvokeAsync
        public async Task InvokeAsync(HttpContext httpContext, ILogService logService)
        {
            CreateLogDto createLogDto = new CreateLogDto()
            {
                RequestPath = httpContext.Request.Path,
                RequestMethod = httpContext.Request.Method,
                RequestProtocol = httpContext.Request.Protocol,
                RequestScheme = httpContext.Request.Scheme,
                RequestHost = httpContext.Request.Host.ToString(),
                //Exception = log.Exception,
                DateTime = DateTime.Now.ToString(),
            };
            logService.PostLog(createLogDto);
            await _next(httpContext);
        }
    }
}

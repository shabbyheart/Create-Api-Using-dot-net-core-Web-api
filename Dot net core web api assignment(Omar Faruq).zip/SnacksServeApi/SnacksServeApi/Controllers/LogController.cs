﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SnacksServeApi.Services.LogServices;
using SnacksServeApi.Services.PersonServices;

namespace SnacksServeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : ControllerBase
    {
        private readonly ILogService _logService;
        public LogController( ILogService logService)
        {
            _logService = logService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var log = _logService.GetLog();
                return Ok(log);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

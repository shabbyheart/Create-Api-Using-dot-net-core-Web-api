﻿using Microsoft.AspNetCore.Mvc;
using SnacksServeApi.ApiResponseHandler;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Services.LogServices;
using SnacksServeApi.Services.SnacksServeTaskServices;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SnacksServeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SnacksServeTasksController : ControllerBase
    {
        private readonly ISnacksServeTaskService _snacksServeTaskService;
        private readonly ILogService _logService;
        public SnacksServeTasksController(ISnacksServeTaskService snackServeTaskService, ILogService logService)
        {
            _snacksServeTaskService = snackServeTaskService;
            _logService = logService;
        }

        [HttpGet]
        public IActionResult GetAllTaskDetails()
        {
            ResponseType type = ResponseType.Success;
            try
            {
                List<SnacksServeTaskDto> data = _snacksServeTaskService.GetAllTaskDetails();
                if (!data.Any())
                {
                    type = ResponseType.NotFound;
                }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
           
        }
        [HttpGet("Id")]
        public IActionResult GetById(string Id)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                SnacksServeTaskDto data = _snacksServeTaskService.GetById(Id);
                if (data == null)
                {
                    type = ResponseType.NotFound;
                }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpGet("{name}")]
        public IActionResult GetByTaskName(string name)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                List<SnacksServeTaskDto> data = _snacksServeTaskService.GetByTaskName(name);
                if (!data.Any())
                {
                    type = ResponseType.NotFound;
                }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        
        [HttpPost]
        public IActionResult CreateTask(CreateSnacksServeTaskDto createTaskDto)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                SnacksServeTaskDto createdTask = _snacksServeTaskService.CreateTask(createTaskDto);
                return Ok(ResponseHandler.GetAppResponse(type, createdTask));
            }
            catch (Exception ex)
            {
                _logService.UpdateLastRow(ex.ToString());
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
        [HttpPost("AllTask")]
        public IActionResult CreateAllTask()
        {
            try
            {
                ResponseType type = ResponseType.Success;
                string msg = _snacksServeTaskService.CreateAllTask();
                return Ok(ResponseHandler.GetAppResponse(type, msg));
            }
            catch (Exception ex)
            {
                _logService.UpdateLastRow(ex.ToString());
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
        [HttpPut]
        public IActionResult Update(UpdateSnacksServeTaskDto task)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                SnacksServeTaskDto data = _snacksServeTaskService.UpdateTask(task);
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
        
        [HttpDelete("{Id}")]
        public IActionResult Delete(string Id)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                return Ok(ResponseHandler.GetAppResponse(type, _snacksServeTaskService.DeleteTask(Id)));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using SnacksServeApi.ApiResponseHandler;
using SnacksServeApi.DTO.PersonDTOs;
using SnacksServeApi.DTO.SnacksServeTaskDTOs;
using SnacksServeApi.Services.LogServices;
using SnacksServeApi.Services.PersonServices;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SnacksServeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonsController : ControllerBase
    {
        private readonly IPersonService _personService;
        private readonly ILogService _logService;
        public PersonsController(IPersonService personService, ILogService logService)
        {
            _personService = personService;
            _logService = logService;
        }

        
        [HttpGet]
        public IActionResult GetALLPerson()
        {
            ResponseType type = ResponseType.Success;
            try
            {
                List<PersonDto> data = _personService.GetAllPersonDetails();
                if (!data.Any())
                {
                    type = ResponseType.NotFound;
                }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                _logService.UpdateLastRow(ex.ToString());
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpGet("{Id}")]
        public IActionResult GetById(string Id)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                PersonDto data = _personService.GetById(Id);
                if (data == null)
                {
                    type = ResponseType.NotFound;
                }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpGet("{name}/requestedTask")]
        public IActionResult GetRequestedTaskByPersonName(string name)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                RequestedSnacksServeTaskDto data = _personService.GetRequestedTaskByPersonName(name);
                if (data == null) { type = ResponseType.NotFound; }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch(Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpGet("{name}/ToDoTasks")]
        public IActionResult GetToDoTasksByPersonName(string name)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                List<ToDoSnacksServeTaskDto> data = _personService.GetToDoTasksByPersonName(name);
                if (!data.Any()) { type = ResponseType.NotFound; }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
        [HttpGet("{name}/CompletedTask")]
        public IActionResult GetCompletedTasksByPersonName(string name)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                List<ShowCompletedSnacksServeTaskDto> data = _personService.GetCompletedTasksByPersonName(name);
                if (!data.Any()) { type = ResponseType.NotFound; }
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpPut("{personId}/CompleteTheTask/{snacksServeTaskId}")]
        public IActionResult CompleteTheTask(string personId, string snacksServeTaskId)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                CompleteSnacksServeTaskDto data = _personService.CompleteTheTask(personId, snacksServeTaskId);
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpPost]
        public IActionResult CreatePerson(CreatePersonDto person)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                PersonDto data = _personService.PersonCreate(person);
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                _logService.UpdateLastRow(ex.ToString());
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        // PUT api/<PersonsController>/5
        [HttpPut]
        public IActionResult Put(UpdatePerssonDto person)
        {
            try
            {
                ResponseType type = ResponseType.Success;
                UpdatePerssonDto data = _personService.UpdatePerson(person);
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }

        [HttpDelete("{Id}")]
        public IActionResult DeleteById(string Id)
        {
            ResponseType type = ResponseType.Success;
            try
            {
                string  data = _personService.DeleteById(Id); 
                return Ok(ResponseHandler.GetAppResponse(type, data));
            }
            catch (Exception ex)
            {
                return BadRequest(ResponseHandler.GetExceptionResponse(ex));
            }
        }
    }
}

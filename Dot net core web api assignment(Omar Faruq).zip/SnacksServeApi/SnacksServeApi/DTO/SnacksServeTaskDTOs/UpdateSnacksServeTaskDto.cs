﻿namespace SnacksServeApi.DTO.SnacksServeTaskDTOs
{
    public class UpdateSnacksServeTaskDto
    {
        public string Id { get; set; } = string.Empty;
        public string SnacksName { get; set; } = string.Empty;
        
    }
}

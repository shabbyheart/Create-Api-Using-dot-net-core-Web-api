﻿using SnacksServeApi.Models;
using System.ComponentModel.DataAnnotations;

namespace SnacksServeApi.DTO.SnacksServeTaskDTOs
{
    public class CreateSnacksServeTaskDto
    {

        //public string Id { get; set; } = string.Empty;
        public string SnacksName { get; set; } = string.Empty;
        public string PersonId { get; set; } = string.Empty;
    }
}

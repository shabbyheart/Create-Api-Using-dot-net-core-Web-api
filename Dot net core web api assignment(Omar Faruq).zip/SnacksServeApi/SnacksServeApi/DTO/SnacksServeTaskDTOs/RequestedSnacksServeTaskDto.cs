﻿namespace SnacksServeApi.DTO.SnacksServeTaskDTOs
{
    public class RequestedSnacksServeTaskDto
    {
        public string Id { get; set; } = String.Empty;
        public string Name { get; set; } = String.Empty;
    }
}

﻿namespace SnacksServeApi.DTO.SnacksServeTaskDTOs
{
    public class SnacksServeTaskDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string PersonId { get; set; } = string.Empty;
        public bool IsComplete { get; set; }
        public string? WhoCompleted { get; set; }
    }
}

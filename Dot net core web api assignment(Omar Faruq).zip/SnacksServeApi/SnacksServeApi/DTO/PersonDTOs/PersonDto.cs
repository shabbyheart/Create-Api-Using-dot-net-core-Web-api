﻿using System.ComponentModel.DataAnnotations;

namespace SnacksServeApi.DTO.PersonDTOs
{
    public class PersonDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string SnacksName { get; set; } = string.Empty;
    }
}

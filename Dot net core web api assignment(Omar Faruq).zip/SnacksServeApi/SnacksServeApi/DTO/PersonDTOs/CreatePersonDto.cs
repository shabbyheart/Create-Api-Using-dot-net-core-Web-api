﻿namespace SnacksServeApi.DTO.PersonDTOs
{
    public class CreatePersonDto
    {
        public string Name { get; set; } = string.Empty;
        public string SnacksName { get; set; } = string.Empty;
    }
}

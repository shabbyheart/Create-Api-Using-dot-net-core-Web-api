﻿namespace SnacksServeApi.DTO.LogDtos
{
    public class LogDto
    {
        public string RequestPath { get; set; } = string.Empty;
        public string RequestMethod { get; set; } = string.Empty;
        public string RequestProtocol { get; set; } = string.Empty;
        public string RequestScheme { get; set; } = string.Empty;
        public string RequestHost { get; set; } = string.Empty;
        public string? Exception { get; set; } = string.Empty;
        public string DateTime { get; set; } = string.Empty;
    }
}
